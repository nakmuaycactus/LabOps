<?php
include 'functions.php';
$pdo = pdo_connect_mysql();
$msg = '';

// Check if POST data is not empty
if (!empty($_POST)) {
  // Post data not empty insert a new record
  // Set-up the variables that are going to be inserted, we must check if the POST variables exist if not we can default them to blank
  $id = isset($_POST['id']) && !empty($_POST['id']) && $_POST['id'] != 'auto' ? $_POST['id'] : NULL;
  // Check if POST variable "name" exists, if not default the value to blank, basically the same for all variables
  $name = isset($_POST['name']) ? $_POST['name'] : '';
  $price = isset($_POST['price']) ? $_POST['price'] : '';
  $rrp = isset($_POST['rrp']) ? $_POST['rrp'] : '';
  $quantity = isset($_POST['quantity']) ? $_POST['quantity'] : '';
  $img = isset($_FILES['fileToUpload']['name']) ? $_FILES['fileToUpload']['name'] : ''; // Use the uploaded file name
  // Insert new record into the products table
  $stmt = $pdo->prepare('INSERT INTO products VALUES (?, ?, ?, ?, ?, ?)');
  $stmt->execute([$id, $name, $price, $rrp, $quantity, $img]);

  // Check if file was uploaded successfully
  if (isset($_FILES["fileToUpload"]) && $_FILES["fileToUpload"]["error"] == 0) {
    $target_dir = "../shoppingcart/images/";
    $target_file = $target_dir . basename($_FILES["fileToUpload"]["name"]);
    $uploadOk = 1;
    $imageFileType = strtolower(pathinfo($target_file, PATHINFO_EXTENSION));

    // Check if image file is a actual image or fake image
    $check = getimagesize($_FILES["fileToUpload"]["tmp_name"]);
    if ($check !== false) {
      echo "File is an image - " . $check["mime"] . ".";
      $uploadOk = 1;
    } else {
      echo "File is not an image.";
      $uploadOk = 0;
    }

    // Check if file already exists
    if (file_exists($target_file)) {
      echo "Sorry, file already exists.";
      $uploadOk = 0;
    }

    // Check file size
    if ($_FILES["fileToUpload"]["size"] > 500000) {
      echo "Sorry, your file is too large.";
      $uploadOk = 0;
    }

    // Allow certain file formats
    if ($imageFileType != "jpg" && $imageFileType != "png" && $imageFileType != "jpeg" && $imageFileType != "gif") {
      echo "Sorry, only JPG, JPEG, PNG & GIF files are allowed.";
      $uploadOk = 0;
    }

    // Check if $uploadOk is set to 0 by an error
    if ($uploadOk == 0) {
      echo "Sorry, your file was not uploaded.";
    } else {
      // if everything is ok, try to upload file
      if (move_uploaded_file($_FILES["fileToUpload"]["tmp_name"], $target_file)) {
        echo "The file " . htmlspecialchars(basename($_FILES["fileToUpload"]["name"])) . " has been uploaded.";
        // Output message
        $msg = 'Product entered successfully!';
        header('Location: ../phpcrud');
        exit;
      } else {
        echo "Sorry, there was an error uploading your file.";
      }
    }
  } else {
    echo "Sorry, there was an error uploading your file.";
  }
}

?>

<?= template_header('Create') ?>

<div class="content update">
  <h2>Create Product</h2>
  <form action="create.php" method="post" enctype="multipart/form-data"> <!-- Add the enctype for file uploads -->
    <label for="id">ID</label>
    <label for="name">Name</label>
    <input type="text" name="id" placeholder="auto" value="auto" id="id">
    <input type="text" name="name" placeholder="Name" id="name">
    <label for="price">Price</label>
    <label for="rrp">RRP</label>
    <input type="text" name="price" placeholder="100" id="price">
    <input type="text" name="rrp" placeholder="120" id="rrp">
    <label for="quantity">Quantity</label>
    <label for="img">File</label>
    <input type="text" name="quantity" placeholder="10" id="quantity">
    <input type="file" name="fileToUpload" id="img"> <!-- Add the input type file for image upload -->
    <input type="submit" value="Create" name="submit"> <!-- Add the name attribute to the submit button -->
  </form>
  <?php if ($msg) : ?>
    <p><?= $msg ?></p>
  <?php endif; ?>
</div>

<?= template_footer() ?>