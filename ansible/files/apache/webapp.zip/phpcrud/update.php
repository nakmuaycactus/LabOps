<?php
include 'functions.php';
$pdo = pdo_connect_mysql();
$msg = '';

// Check if the product id exists, for example update.php?id=1 will get the product with the id of 1
if (isset($_GET['id'])) {
    if (!empty($_POST)) {
        // This part is similar to the create.php, but instead we update a record and not insert
        $id = isset($_POST['id']) ? $_POST['id'] : NULL;
        $name = isset($_POST['name']) ? $_POST['name'] : '';
        $price = isset($_POST['price']) ? $_POST['price'] : '';
        $rrp = isset($_POST['rrp']) ? $_POST['rrp'] : '';
        $quantity = isset($_POST['quantity']) ? $_POST['quantity'] : '';
        $img = isset($_FILES['fileToUpload']['name']) ? $_FILES['fileToUpload']['name'] : $_POST['img']; // If a new image is uploaded, use the uploaded file name, otherwise use the existing image name

        // Update the record
        $stmt = $pdo->prepare('UPDATE products SET id = ?, name = ?, price = ?, rrp = ?, quantity = ?, img = ? WHERE id = ?');
        $stmt->execute([$id, $name, $price, $rrp, $quantity, $img, $_GET['id']]);

        // Check if file was uploaded successfully
        if (isset($_FILES["fileToUpload"]) && $_FILES["fileToUpload"]["error"] == 0) {
            $target_dir = "../shoppingcart/images/";
            $target_file = $target_dir . basename($_FILES["fileToUpload"]["name"]);
            $uploadOk = 1;
            $imageFileType = strtolower(pathinfo($target_file, PATHINFO_EXTENSION));

            // Check if image file is a actual image or fake image
            $check = getimagesize($_FILES["fileToUpload"]["tmp_name"]);
            if ($check !== false) {
                echo "File is an image - " . $check["mime"] . ".";
                $uploadOk = 1;
            } else {
                echo "File is not an image.";
                $uploadOk = 0;
            }

            // Check if file already exists
            if (file_exists($target_file)) {
                echo "Sorry, file already exists.";
                $uploadOk = 0;
            }

            // Check file size
            if ($_FILES["fileToUpload"]["size"] > 500000) {
                echo "Sorry, your file is too large.";
                $uploadOk = 0;
            }

            // Allow certain file formats
            if ($imageFileType != "jpg" && $imageFileType != "png" && $imageFileType != "jpeg" && $imageFileType != "gif") {
                echo "Sorry, only JPG, JPEG, PNG & GIF files are allowed.";
                $uploadOk = 0;
            }

            // Check if $uploadOk is set to 0 by an error
            if ($uploadOk == 0) {
                echo "Sorry, your file was not uploaded.";
            } else {
                // if everything is ok, try to upload file
                if (move_uploaded_file($_FILES["fileToUpload"]["tmp_name"], $target_file)) {
                    echo "The file " . htmlspecialchars(basename($_FILES["fileToUpload"]["name"])) . " has been uploaded.";
                } else {
                    echo "Sorry, there was an error uploading your file.";
                }
            }
        }

        $msg = 'Updated Successfully!';
        header('Location: ../phpcrud');
        exit;
    }

    // Get the product from the products table
    $stmt = $pdo->prepare('SELECT * FROM products WHERE id = ?');
    $stmt->execute([$_GET['id']]);
    $product = $stmt->fetch(PDO::FETCH_ASSOC);
    if (!$product) {
        exit('product doesn\'t exist with that ID!');
    }
} else {
    exit('No ID specified!');
}
?>

<?= template_header('Update') ?>

<div class="content update">
    <h2>Update product #<?= $product['id'] ?></h2>
    <form action="update.php?id=<?= $product['id'] ?>" method="post" enctype="multipart/form-data"> <!-- Add the enctype for file uploads -->
        <label for="id">ID</label>
        <label for="name">Name</label>
        <input type="text" name="id" placeholder="1" value="<?= $product['id'] ?>" id="id">
        <input type="text" name="name" placeholder="Name" value="<?= $product['name'] ?>" id="name">
        <label for="price">Price</label>
        <label for="rrp">RRP</label>
        <input type="text" name="price" placeholder="$100" value="<?= $product['price'] ?>" id="price">
        <input type="text" name="rrp" placeholder="$120" value="<?= $product['rrp'] ?>" id="rrp">
        <label for="quantity">Quantity</label>
        <label for="img">File</label>
        <input type="text" name="quantity" placeholder="10" value="<?= $product['quantity'] ?>" id="quantity">
        <input type="text" name="img" placeholder="gold.jpg" value="<?= $product['img'] ?>" id="img">
        <input type="file" name="fileToUpload" id="img"> <!-- Add the input type file for image upload -->
        <input type="submit" value="Update">
    </form>
    <?php if ($msg) : ?>
        <p><?= $msg ?></p>
    <?php endif; ?>
</div>

<?= template_footer() ?>