# autoAD

Internship project by Blair and Jesse

## TODO
- automate object setup (users, groups)
